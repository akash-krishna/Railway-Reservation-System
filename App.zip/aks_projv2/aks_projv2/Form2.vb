﻿Imports System.Data.SqlClient
Public Class Form2
    Public con As SqlConnection = New SqlConnection("Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = master; Integrated Security = True")
    Public type As Integer = 0 : Public sa As Integer
    Private Sub Form2_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Label1.Hide()
        Label2.Hide()
        Label3.Hide()
        Label20.Hide()
        Label21.Hide()
        Label24.Hide()
        Label25.Hide()
        Label32.Hide()
        LinkLabel1.Hide()
        RadioButton1.Hide()
        RadioButton2.Hide()
        RadioButton3.Hide()
        RadioButton4.Hide()
        ComboBox16.Hide()
        If Form1.type = 1 Then
            Me.Text = "CANCEL TICKET"
            Me.BackColor = Color.IndianRed
            Button2.Hide()
        ElseIf Form1.type = 2 Then
            RadioButton1.Checked = True
            RadioButton1.Show()
            RadioButton2.Show()
            RadioButton1.Text = "BOOKED HISTORY"
            RadioButton2.Text = "CANCELLATION HISTORY"
            Button2.Show()
        Else
            Button2.Hide()
            Label1.Show()
            Label2.Show()
            Label3.Show()
            Label20.Show()
            Label21.Show()
            Label32.Show()
            RadioButton1.Show()
            RadioButton2.Show()
            RadioButton3.Show()
            RadioButton4.Show()
            Label1.Text = Form1.ComboBox1.SelectedItem
            Label2.Text = Form1.ComboBox2.SelectedItem
            Label21.Text = Form1.MonthCalendar1.SelectionStart.ToShortDateString
            Form3.Label34.Text = RadioButton1.Text
        End If
    End Sub
    Private Sub DataGridClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            Dim s As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            If Not Form1.type = 0 Then
                Form4.Label82.Text = s.Cells(0).Value.ToString()
                Form4.Label57.Text = s.Cells(1).Value.ToString()
                Form4.Label2.Text = s.Cells(2).Value.ToString()
                Form4.Label80.Text = s.Cells(3).Value.ToString()
                Form4.Label86.Text = s.Cells(5).Value.ToString()
                If Form1.type = 1 Then type = 1 Else type = 2
                If Form1.type = 2 And RadioButton2.Checked = True Then type = 3
                Me.Hide()
                Form4.Show()
            ElseIf Form1.type = 0 Then
                Form3.Label21.Text = s.Cells(0).Value.ToString()
                Form3.Label1.Text = s.Cells(1).Value.ToString()
                Form3.Label3.Text = s.Cells(2).Value.ToString()
                Form3.Label19.Text = s.Cells(3).Value.ToString()
                Form3.Label4.Text = s.Cells(4).Value.ToString()
                Form3.Label20.Text = s.Cells(5).Value.ToString()
                Form3.Label23.Text = s.Cells(6).Value.ToString() & "/- Rs."
                If Form1.MonthCalendar1.SelectionStart = Today And Form3.Label19.Text <= TimeOfDay Then
                    MsgBox("TRAIN DEPARTED!", MsgBoxStyle.Exclamation, "NOT ALLOWED")
                Else
                    Label24.Show()
                    ComboBox16.Show()
                    ComboBox16.SelectedIndex = -1
                    LinkLabel1.Hide()
                End If
            End If
        Catch c As ArgumentOutOfRangeException
            MsgBox("PLEASE CLICK ON THE ROW CELL TO SELECT THAT TRAIN/RECORD", MsgBoxStyle.Information, "SELECTION")
        End Try
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        If Form1.type = 2 And RadioButton1.Checked = True Then
            Me.Text = "BOOKED HISTORY"
            Me.BackColor = Color.CadetBlue
            Dim com As SqlCommand = New SqlCommand("select * from RECORDS where TICKET_STATUS='CONFIRMED' ORDER BY PNR_NUM DESC", con)
            Dim da As SqlDataAdapter = New SqlDataAdapter(com)
            Dim ds As DataSet = New DataSet()
            da.Fill(ds, "RECORDS")
            DataGridView1.DataSource = ds.Tables(0)
            con.Close()
        ElseIf Form1.type = 0 Then
            If RadioButton1.Checked = True Then Form3.Label34.Text = RadioButton1.Text
            LinkLabel1.Hide()
            ComboBox16.SelectedIndex = -1
        End If
    End Sub
    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        If Form1.type = 2 And RadioButton2.Checked = True Then
            Me.Text = "CANCELLED HISTORY"
            Me.BackColor = Color.IndianRed
            Dim com As SqlCommand = New SqlCommand("select * from CANCELLED where TICKET_STATUS='CANCELLED' ORDER BY PNR_NUM DESC", con)
            Dim da As SqlDataAdapter = New SqlDataAdapter(com)
            Dim ds As DataSet = New DataSet()
            da.Fill(ds, "CANCELLED")
            DataGridView1.DataSource = ds.Tables(0)
            con.Close()
        ElseIf Form1.type = 0 Then
            If RadioButton2.Checked = True Then Form3.Label34.Text = RadioButton2.Text
            LinkLabel1.Hide()
            ComboBox16.SelectedIndex = -1
            If RadioButton2.Checked = True Then MsgBox("Handicapped passengers need to carry Photo Identity card issued by Railways which is to be produced for On-board / Off-board verification during journey." + vbNewLine + "Escort passengers also need to carry photo identity card mentioned at the time of booking." + vbNewLine + "No normal passenger other than Physically Handicap / Escort is allowed." + vbNewLine + "No Senior Citizen concession will be available for this Quota.", MsgBoxStyle.Information, "PHYSICALLY HANDICAPPED QUOTA")
        End If
    End Sub
    Private Sub CLEAR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim i As Integer = MsgBox("ARE YOU SURE...?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.ApplicationModal, "DELETE OLD RECORDS")
        If i = MsgBoxResult.Yes Then
            con.Open()
            If Form1.type = 2 And RadioButton1.Checked = True Then
                Dim com As SqlCommand = New SqlCommand("DELETE FROM HISTORY WHERE TICKET_STATUS='CONFIRMED' AND JOURNEY_DATE<'" + Today.ToShortDateString + "' ", con)
                com.ExecuteNonQuery()
            ElseIf Form1.type = 2 And RadioButton2.Checked = True Then
                Dim com As SqlCommand = New SqlCommand("DELETE FROM HISTORY WHERE TICKET_STATUS='CANCELLED'", con)
                com.ExecuteNonQuery()
            End If
            Dim cmd As SqlCommand = New SqlCommand("DELETE FROM DETAILS WHERE PNR_NO NOT IN (SELECT PNR_NUM FROM HISTORY)", con)
            cmd.ExecuteNonQuery()
            Me.Close()
            con.Close()
            Form1.Show()
        End If
    End Sub
    Private Sub CLASS_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox16.SelectedIndexChanged
        sa = 0 : Dim ns As Integer = 100 : con.Open()
        Dim com As SqlCommand = New SqlCommand("SELECT SUM(NO_PASSENGERS) FROM HISTORY WHERE BOOKED_TRAIN = '" + Form3.Label21.Text + "' AND JOURNEY_DATE='" + Label21.Text.ToString + "' AND QUOTA='" + Form3.Label34.Text + "' AND CLASS='" + ComboBox16.SelectedItem + "' AND TICKET_STATUS='CONFIRMED'", con)
        Dim dr = com.ExecuteReader():dr.Read()
        If Not dr.IsDBNull(0) Then sa = dr(0)
        sa = ns - sa
        Label25.Show() : LinkLabel1.Show()
        If sa <= 0 Then LinkLabel1.Enabled = False
        If sa >= 1 And sa < 6 Then
            LinkLabel1.Text = "CURR_AVBL : " & sa:Form3.NumericUpDown6.Maximum = sa
        Else : LinkLabel1.Text = "CURR_AVBL : " & sa:Form3.NumericUpDown6.Maximum = 6
        End If:con.Close()
    End Sub

    Private Sub SEAT_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Form3.Label24.Text = ComboBox16.SelectedItem
        Form3.Show():Me.Hide()
    End Sub
    Private Sub RETURN_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Me.Close()
        Form1.type = 0
        Form1.Show()
    End Sub
    Private Sub LADIES(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked = True Then Form3.Label34.Text = RadioButton3.Text
        LinkLabel1.Hide()
        ComboBox16.SelectedIndex = -1
    End Sub
    Private Sub TATKAL(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton4.CheckedChanged
        If Not Form1.type = 1 Or Form1.type = 2 Then
            If RadioButton4.Checked = True Then
                MsgBox("Tatkal is available only between 9:45 – 10:15 (AC) and 10:45 – 11:15 (Sleeper)", MsgBoxStyle.Information, "NOT AVAILABLE")
                RadioButton4.Checked = False
                RadioButton1.Checked = True
                LinkLabel1.Hide()
                ComboBox16.SelectedIndex = -1
            End If
        End If
    End Sub
    Public Sub DataGridView_ColumnClick(ByVal sender As Object, ByVal e As DataGridViewCellMouseEventArgs) Handles DataGridView1.RowHeaderMouseClick
        MsgBox("CLICK ON THE ROW CELLS TO SELECT THAT TRAIN/RECORD", MsgBoxStyle.Information, "SELECTION")
    End Sub
End Class