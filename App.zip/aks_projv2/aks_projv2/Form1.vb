﻿Imports System.Data.SqlClient
Public Class Form1
    Public con As SqlConnection = New SqlConnection("Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = master; Integrated Security = True")
    Public type As Integer = 0
    Public log As Integer
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        If log = 0 Then
            Me.Text = "ADMIN LOGIN"
            Me.BackgroundImage = WindowsApplication1.My.Resources.Resources.login
            Label1.Hide()
            Label3.Hide()
            Label4.Hide()
            Label5.Hide()
            Label6.Hide()
            Label8.Show()
            LinkLabel1.Hide()
            ComboBox1.Hide()
            ComboBox2.Hide()
            TextBox1.Show()
            Button1.Hide()
            Button2.Hide()
            Button3.Hide()
            Button4.Hide()
            Button5.Hide()
            MonthCalendar1.Hide()
        ElseIf log = 1 Then
            Me.Text = "JOURNEY PLANNER"
            Me.BackgroundImage = WindowsApplication1.My.Resources.Resources.track
            Label1.Show()
            Label3.Show()
            Label4.Show()
            Label5.Show()
            Label6.Show()
            Label8.Hide()
            LinkLabel1.Show()
            ComboBox1.Show()
            ComboBox2.Show()
            ComboBox1.SelectedIndex = -1
            ComboBox2.SelectedIndex = -1
            Button1.Show()
            Button2.Show()
            Button3.Show()
            Button4.Show()
            Button5.Show()
            TextBox1.Hide()
            MonthCalendar1.Show()
            MonthCalendar1.MinDate = Today.ToShortDateString
        End If
    End Sub
    Private Sub SUMBIT_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        If ComboBox1.SelectedItem = "" OrElse ComboBox2.SelectedItem = "" Then
            MsgBox("PLEASE ENTER A VALID STATION NAME!", MsgBoxStyle.Exclamation, "JOURNEY DETAILS")
        ElseIf ComboBox1.SelectedItem = ComboBox2.SelectedItem Then
            MsgBox("FROM AND TO STATION CANNOT BE THE SAME!", MsgBoxStyle.Exclamation, "JOURNEY DETAILS")
        Else
            Dim com As SqlCommand = New SqlCommand("select * from TRAINS where FROM_STATION='" + ComboBox1.SelectedItem + "' and TO_STATION='" + ComboBox2.SelectedItem + "'", con)
            Dim da As SqlDataAdapter = New SqlDataAdapter(com)
            Dim ds As DataSet = New DataSet() : da.Fill(ds, "TRAINS")
            Form2.DataGridView1.DataSource = ds.Tables(0).DefaultView
            If Form2.DataGridView1.RowCount = 0 Then
                MsgBox("NO MATCHING TRAINS FOUND", MsgBoxStyle.Exclamation, "NOT FOUND")
            Else : Form2.Show() : Form3.Label2.Text = MonthCalendar1.SelectionStart.ToShortDateString : Me.Hide()
            End If
            con.Close()
        End If
    End Sub
    Private Sub CANCEL_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button3.Click
        Dim com As SqlCommand = New SqlCommand("select * from RECORDS where TICKET_STATUS='CONFIRMED' and JOURNEY_DATE>'" + Today + "'", con)
        Dim da As SqlDataAdapter = New SqlDataAdapter(com)
        Dim ds As DataSet = New DataSet()
        da.Fill(ds, "RECORDS")
        Form2.DataGridView1.DataSource = ds.Tables(0)
        If Form2.DataGridView1.Rows.Count = 0 Then
            MsgBox("NO CANCELLABLE TICKETS FOUND", MsgBoxStyle.Exclamation, "NO RECORDS")
        Else : type = 1 : Me.Hide() : Form2.Show()
        End If
        con.Close()
    End Sub
    Private Sub HISTORY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        type = 2
        Me.Hide()
        Form2.Show()
    End Sub
    Private Sub RESET_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
        ComboBox1.SelectedIndex = -1
        ComboBox2.SelectedIndex = -1
        MonthCalendar1.SelectionStart = Today.ToShortDateString
    End Sub
    Private Sub SWAP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim s As String = ComboBox1.SelectedItem
        ComboBox1.SelectedItem = ComboBox2.SelectedItem
        ComboBox2.SelectedItem = s
    End Sub
    Private Sub Timer_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        Label1.Text = Now + " IST"
    End Sub
    Private Sub LOGOUT_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim i As Integer = MsgBox("Are You Sure You Want To Logout...?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.ApplicationModal, "LOGOUT")
        If i = MsgBoxResult.Yes Then
            log = 0
            MyBase.OnLoad(e)
            Label8.Text = "USER ID"
            TextBox1.Clear()
            ComboBox1.SelectedIndex = -1
            ComboBox2.SelectedIndex = -1
        End If
    End Sub
    Private Sub ABOUT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click
        MsgBox("AKASH KRISHNA.S" + vbNewLine + "BACHELOR OF COMPUTER APPLICATIONS," + vbNewLine + "MADRAS CHRISTIAN COLLEGE." + vbNewLine + vbNewLine + "Copyright© 2017 - 157CS214. All Rights Reserved.", MsgBoxStyle.Information, "ABOUT")
    End Sub
    Private Sub LOGIN_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        If Label8.Text = "USER ID" Then
            If TextBox1.Text = "AKASH" And TextBox1.TextLength > 4 Then
                Label8.Text = "PASSWORD"
                TextBox1.Clear()
            ElseIf Not TextBox1.Text = "AKASH" And TextBox1.TextLength > 4 Then
                MsgBox("INVALID CREDENTIALS!", MsgBoxStyle.Critical, "ERROR")
                TextBox1.Clear()
            End If
        ElseIf Label8.Text = "PASSWORD" Then
            TextBox1.PasswordChar = "●"
            If TextBox1.Text = "KRISHNA" And TextBox1.TextLength > 6 Then
                log = 1
                TextBox1.PasswordChar = Nothing
                MyBase.OnLoad(e)
            ElseIf Not TextBox1.Text = "KRISHNA" And TextBox1.TextLength > 6 Then
                MsgBox("INVALID CREDENTIALS!", MsgBoxStyle.Critical, "ERROR")
                TextBox1.Clear()
            End If
        End If
    End Sub
End Class