﻿Public Class Form3
    Public pn(11), pg(19), pa(7) As String
    Private Sub Form3_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Button1.Hide()
        Dim i As Integer
        For i = 2 To 12
            If i = 6 Then
                i += 1
            End If
            Dim txt = Controls("TextBox" & i)
            txt.Hide()
        Next
        For i = 2 To 7
            If i = 6 Then
                i += 1
            End If
            Dim nud = Controls("NumericUpDown" & i)
            nud.Hide()
        Next
        For i = 13 To 32
            If i = 17 Then
                i += 15
            End If
            Dim lbl = Controls("Label" & i)
            lbl.Hide()
        Next
        For i = 2 To 19
            If i = 16 Or i = 6 Or i = 11 Then
                i += 1
            End If
            Dim cmb = Controls("ComboBox" & i)
            cmb.Hide()
        Next
        For i = 6 To 18
            If i = 11 Then
                i += 7
            End If
            Dim cmb = Controls("ComboBox" & i)
            cmb.Text = "No Preference"
        Next
        For i = 11 To 17
            If i = 16 Then
                i += 1
            End If
            Dim cmb = Controls("ComboBox" & i)
            cmb.Text = "India"
        Next
    End Sub

    Private Sub BOOKNOW_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        For i As Integer = 1 To 11:Dim txt = Controls("TextBox" & i):pn(i) = txt.Text:Next
        For i As Integer = 1 To 7 : If i = 6 Then i += 1
            Dim txt = Controls("NumericUpDown" & i) : pa(i) = txt.Text : Next
        For i As Integer = 1 To 19 : If i = 16 Then i += 1
            Dim txt = Controls("ComboBox" & i) : pg(i) = txt.Text : Next

        If NumericUpDown6.Value = 1 Then
            If TextBox1.Text = "" Or NumericUpDown1.Value = 0 Or ComboBox1.SelectedItem = "" Or ComboBox6.SelectedItem = "" Or ComboBox11.SelectedItem = "" Then
                MsgBox("PLEASE ENTER ALL THE DETAILS CORRECTLY.", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown1.Value > 11 And ComboBox1.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown1.Value = 0
                ComboBox1.Text = ""
            ElseIf ComboBox6.SelectedItem = "No Berth" Then
                MsgBox("Number of child without berth option must be equal to number of passengers with berth", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf NumericUpDown1.Value < 5 Then
                MsgBox("Ticket(s) Not To Be Issued!", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            Else : Form4.Show() : Me.Hide()
            End If

        ElseIf NumericUpDown6.Value = 2 Then
            If TextBox1.Text = "" Or NumericUpDown1.Value = 0 Or ComboBox1.SelectedItem = "" Or ComboBox6.SelectedItem = "" Or ComboBox11.SelectedItem = "" Or TextBox2.Text = "" Or NumericUpDown2.Value = 0 Or ComboBox2.SelectedItem = "" Or ComboBox7.SelectedItem = "" Or ComboBox12.SelectedItem = "" Then
                MsgBox("PLEASE ENTER ALL THE DETAILS CORRECTLY.", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown1.Value > 11 And ComboBox1.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown1.Value = 0
                ComboBox1.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown2.Value > 11 And ComboBox2.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown2.Value = 0
                ComboBox2.Text = ""
            ElseIf ComboBox7.SelectedItem = "No Berth" And ComboBox6.SelectedIndex > 5 Then
                MsgBox("Number of child without berth option must be equal to number of passengers with berth", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf NumericUpDown1.Value < 5 And NumericUpDown2.Value < 5 Then
                MsgBox("Ticket(s) Not To Be Issued!", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            Else : Form4.Show() : Me.Hide()
            End If

        ElseIf NumericUpDown6.Value = 3 Then
            If TextBox1.Text = "" Or NumericUpDown1.Value = 0 Or ComboBox1.SelectedItem = "" Or ComboBox6.SelectedItem = "" Or ComboBox11.SelectedItem = "" Or TextBox2.Text = "" Or NumericUpDown2.Value = 0 Or ComboBox2.SelectedItem = "" Or ComboBox7.SelectedItem = "" Or ComboBox12.SelectedItem = "" Or TextBox3.Text = "" Or NumericUpDown3.Value = 0 Or ComboBox3.SelectedItem = "" Or ComboBox8.SelectedItem = "" Or ComboBox13.SelectedItem = "" Then
                MsgBox("PLEASE ENTER ALL THE DETAILS CORRECTLY.", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown1.Value > 11 And ComboBox1.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown1.Value = 0
                ComboBox1.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown2.Value > 11 And ComboBox2.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown2.Value = 0
                ComboBox2.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown3.Value > 11 And ComboBox3.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown3.Value = 0
                ComboBox3.Text = ""
            ElseIf ComboBox8.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox8.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox6.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" Then
                MsgBox("Number of child without berth option must be equal to number of passengers with berth", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf NumericUpDown1.Value < 5 And NumericUpDown2.Value < 5 And NumericUpDown3.Value < 5 Then
                MsgBox("Ticket(s) Not To Be Issued!", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            Else : Form4.Show() : Me.Hide()
            End If

        ElseIf NumericUpDown6.Value = 4 Then
            If TextBox1.Text = "" Or NumericUpDown1.Value = 0 Or ComboBox1.SelectedItem = "" Or ComboBox6.SelectedItem = "" Or ComboBox11.SelectedItem = "" Or TextBox2.Text = "" Or NumericUpDown2.Value = 0 Or ComboBox2.SelectedItem = "" Or ComboBox7.SelectedItem = "" Or ComboBox12.SelectedItem = "" Or TextBox3.Text = "" Or NumericUpDown3.Value = 0 Or ComboBox3.SelectedItem = "" Or ComboBox8.SelectedItem = "" Or ComboBox13.SelectedItem = "" Or TextBox4.Text = "" Or NumericUpDown4.Value = 0 Or ComboBox4.SelectedItem = "" Or ComboBox9.SelectedItem = "" Or ComboBox14.SelectedItem = "" Then
                MsgBox("PLEASE ENTER ALL THE DETAILS CORRECTLY.", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown1.Value > 11 And ComboBox1.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown1.Value = 0
                ComboBox1.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown2.Value > 11 And ComboBox2.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown2.Value = 0
                ComboBox2.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown3.Value > 11 And ComboBox3.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown3.Value = 0
                ComboBox3.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown4.Value > 11 And ComboBox4.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown4.Value = 0
                ComboBox4.Text = ""
            ElseIf ComboBox9.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox9.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox9.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox8.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox7.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" Then
                MsgBox("Number of child without berth option must be equal to number of passengers with berth", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf NumericUpDown1.Value < 5 And NumericUpDown2.Value < 5 And NumericUpDown3.Value < 5 And NumericUpDown4.Value < 5 Then
                MsgBox("Ticket(s) Not To Be Issued!", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            Else : Form4.Show() : Me.Hide()
            End If

        ElseIf NumericUpDown6.Value = 5 Then
            If TextBox1.Text = "" Or NumericUpDown1.Value = 0 Or ComboBox1.SelectedItem = "" Or ComboBox6.SelectedItem = "" Or ComboBox11.SelectedItem = "" Or TextBox2.Text = "" Or NumericUpDown2.Value = 0 Or ComboBox2.SelectedItem = "" Or ComboBox7.SelectedItem = "" Or ComboBox12.SelectedItem = "" Or TextBox3.Text = "" Or NumericUpDown3.Value = 0 Or ComboBox3.SelectedItem = "" Or ComboBox8.SelectedItem = "" Or ComboBox13.SelectedItem = "" Or TextBox4.Text = "" Or NumericUpDown4.Value = 0 Or ComboBox4.SelectedItem = "" Or ComboBox9.SelectedItem = "" Or ComboBox14.SelectedItem = "" Or TextBox5.Text = "" Or NumericUpDown5.Value = 0 Or ComboBox5.SelectedItem = "" Or ComboBox10.SelectedItem = "" Or ComboBox15.SelectedItem = "" Then
                MsgBox("PLEASE ENTER ALL THE DETAILS CORRECTLY.", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown1.Value > 11 And ComboBox1.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown1.Value = 0
                ComboBox1.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown2.Value > 11 And ComboBox2.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown2.Value = 0
                ComboBox2.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown3.Value > 11 And ComboBox3.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown3.Value = 0
                ComboBox3.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown4.Value > 11 And ComboBox4.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown4.Value = 0
                ComboBox4.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown5.Value > 11 And ComboBox5.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown5.Value = 0
                ComboBox4.Text = ""
            ElseIf ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" OrElse ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox10.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox10.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox10.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox8.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" Then
                MsgBox("Number of child without berth option must be equal to number of passengers with berth", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf NumericUpDown1.Value < 5 And NumericUpDown2.Value < 5 And NumericUpDown3.Value < 5 And NumericUpDown4.Value < 5 And NumericUpDown5.Value < 5 Then
                MsgBox("Ticket(s) Not To Be Issued!", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            Else : Form4.Show() : Me.Hide()
            End If

        ElseIf NumericUpDown6.Value = 6 Then
            If TextBox1.Text = "" Or NumericUpDown1.Value = 0 Or ComboBox1.SelectedItem = "" Or ComboBox6.SelectedItem = "" Or ComboBox11.SelectedItem = "" Or TextBox2.Text = "" Or NumericUpDown2.Value = 0 Or ComboBox2.SelectedItem = "" Or ComboBox7.SelectedItem = "" Or ComboBox12.SelectedItem = "" Or TextBox3.Text = "" Or NumericUpDown3.Value = 0 Or ComboBox3.SelectedItem = "" Or ComboBox8.SelectedItem = "" Or ComboBox13.SelectedItem = "" Or TextBox4.Text = "" Or NumericUpDown4.Value = 0 Or ComboBox4.SelectedItem = "" Or ComboBox9.SelectedItem = "" Or ComboBox14.SelectedItem = "" Or TextBox5.Text = "" Or NumericUpDown5.Value = 0 Or ComboBox5.SelectedItem = "" Or ComboBox10.SelectedItem = "" Or ComboBox15.SelectedItem = "" Or TextBox12.Text = "" Or NumericUpDown6.Value = 0 Or ComboBox19.SelectedItem = "" Or ComboBox18.SelectedItem = "" Or ComboBox17.SelectedItem = "" Then
                MsgBox("PLEASE ENTER ALL THE DETAILS CORRECTLY.", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown1.Value > 11 And ComboBox1.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown1.Value = 0
                ComboBox1.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown2.Value > 11 And ComboBox2.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown2.Value = 0
                ComboBox2.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown3.Value > 11 And ComboBox3.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown3.Value = 0
                ComboBox3.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown4.Value > 11 And ComboBox4.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown4.Value = 0
                ComboBox4.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown5.Value > 11 And ComboBox5.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown5.Value = 0
                ComboBox4.Text = ""
            ElseIf Form2.RadioButton3.Checked = True And NumericUpDown7.Value > 11 And ComboBox6.SelectedItem = "MALE" Then
                MsgBox("For ladies quota, male passenger should not be older than 11 yr", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
                NumericUpDown7.Value = 0
                ComboBox19.Text = ""
            ElseIf ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox9.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox8.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox18.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox8.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" OrElse ComboBox8.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox9.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" OrElse ComboBox8.SelectedItem = "No Berth" And ComboBox10.SelectedItem = "No Berth" And ComboBox6.SelectedItem = "No Berth" And ComboBox7.SelectedItem = "No Berth" Then
                MsgBox("Number of child without berth option must be equal to number of passengers with berth", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            ElseIf NumericUpDown1.Value < 5 And NumericUpDown2.Value < 5 And NumericUpDown3.Value < 5 And NumericUpDown4.Value < 5 And NumericUpDown5.Value < 5 And NumericUpDown7.Value < 5 Then
                MsgBox("Ticket(s) Not To Be Issued!", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
            Else : Form4.Show() : Me.Hide()
            End If
        End If
    End Sub

    Private Sub PASSENGER_ValueChanged(ByVal sender As Object, ByVal e As EventArgs) Handles NumericUpDown6.ValueChanged
        If NumericUpDown6.Value = 1 Then
            For i As Integer = 13 To 32
                If i = 17 Then
                    i += 15
                End If
                Dim lbl = Controls("Label" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next
            For i As Integer = 2 To 12
                If i = 6 Then
                    i += 1
                End If
                Dim lbl = Controls("TextBox" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next
            For i As Integer = 2 To 7
                If i = 6 Then
                    i += 1
                End If
                Dim lbl = Controls("NumericUpDown" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next
            For i As Integer = 2 To 19
                If i = 6 Or i = 11 Or i = 16 Then
                    i += 1
                End If
                Dim lbl = Controls("ComboBox" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next

        ElseIf NumericUpDown6.Value = 2 Then
            Label13.Show()
            TextBox2.Show()
            TextBox7.Show()
            ComboBox2.Show()
            ComboBox7.Show()
            ComboBox12.Show()
            NumericUpDown2.Show()
            For i As Integer = 14 To 32
                If i = 17 Then
                    i += 15
                End If
                Dim lbl = Controls("Label" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next
            For i As Integer = 3 To 12
                If i = 6 Then
                    i += 2
                End If
                Dim lbl = Controls("TextBox" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next
            For i As Integer = 3 To 7
                If i = 6 Then
                    i += 1
                End If
                Dim lbl = Controls("NumericUpDown" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next
            For i As Integer = 3 To 19
                If i = 6 Or i = 11 Then
                    i += 2
                End If
                If i = 16 Then
                    i += 1
                End If
                Dim lbl = Controls("ComboBox" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next

        ElseIf NumericUpDown6.Value = 3 Then
            Label14.Show()
            TextBox3.Show()
            TextBox8.Show()
            ComboBox3.Show()
            ComboBox8.Show()
            ComboBox13.Show()
            NumericUpDown3.Show()
            For i As Integer = 15 To 32
                If i = 17 Then
                    i += 15
                End If
                Dim lbl = Controls("Label" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next
            For i As Integer = 4 To 11
                If i = 6 Then
                    i += 3
                End If
                Dim lbl = Controls("TextBox" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next
            For i As Integer = 4 To 7
                If i = 6 Then
                    i += 1
                End If
                Dim lbl = Controls("NumericUpDown" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next
            For i As Integer = 4 To 19
                If i = 6 Or i = 11 Then
                    i += 3
                End If
                If i = 16 Then
                    i += 1
                End If
                Dim lbl = Controls("ComboBox" & i.ToString())
                If lbl IsNot Nothing Then
                    lbl.Hide()
                End If
            Next

        ElseIf NumericUpDown6.Value = 4 Then
            Label15.Show()
            TextBox4.Show()
            TextBox9.Show()
            ComboBox4.Show()
            ComboBox9.Show()
            ComboBox14.Show()
            NumericUpDown4.Show()
            Label16.Hide()
            TextBox5.Hide()
            TextBox10.Hide()
            ComboBox5.Hide()
            ComboBox10.Hide()
            ComboBox15.Hide()
            NumericUpDown5.Hide()
            TextBox12.Hide()
            TextBox11.Hide()
            ComboBox19.Hide()
            ComboBox18.Hide()
            ComboBox17.Hide()
            NumericUpDown7.Hide()

        ElseIf NumericUpDown6.Value = 5 Then
            Label16.Show()
            TextBox5.Show()
            TextBox10.Show()
            ComboBox5.Show()
            ComboBox10.Show()
            ComboBox15.Show()
            NumericUpDown5.Show()
            Label32.Hide()
            TextBox12.Hide()
            TextBox11.Hide()
            ComboBox19.Hide()
            ComboBox18.Hide()
            ComboBox17.Hide()
            NumericUpDown7.Hide()

        ElseIf NumericUpDown6.Value = 6 Then
            Label32.Show()
            TextBox12.Show()
            TextBox11.Show()
            ComboBox19.Show()
            ComboBox18.Show()
            ComboBox17.Show()
            NumericUpDown7.Show()
        End If
    End Sub

    Private Sub RESET_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
        For Each ctl In Controls
            If TypeOf ctl Is NumericUpDown Then ctl.Text = ""
            If TypeOf ctl Is TextBox Then ctl.Text = ""
            If TypeOf ctl Is ComboBox Then ctl.SelectedIndex = -1
        Next ctl
        NumericUpDown6.Text = 1
    End Sub
    Private Sub RETURN_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button3.Click
        Me.Hide()
        Form2.Show()
    End Sub
    Private Sub CANCEL_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button4.Click
        Dim i As Integer = MsgBox("ARE YOU SURE...?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.ApplicationModal, "CANCEL")
        If i = MsgBoxResult.Yes Then
            Me.Close()
            Form2.Close()
            Form1.Show()
        End If
    End Sub

    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        If NumericUpDown1.Value < 5 Then
            If Not ComboBox6.Items.Contains("No Berth Alotted") Then ComboBox6.Items.Add("No Berth Alotted")
            ComboBox6.SelectedItem = "No Berth Alotted":ComboBox6.Enabled = False
            TextBox6.Text = "CHILD (TICKET NOT NEEDED)"
        ElseIf NumericUpDown1.Value >= 5 And NumericUpDown1.Value <= 11 Then
            ComboBox6.Enabled = True
            If Not ComboBox6.Items.Contains("No Berth") Then ComboBox6.Items.Add("No Berth")
        ComboBox6.Items.Remove("No Berth Alotted")
        ComboBox6.SelectedItem = "No Berth"
        TextBox6.Text = "CHILD (HALF THE ADULT FARE)"
        End If
        If Form2.RadioButton2.Checked = False Then
            If NumericUpDown1.Value > 11 And NumericUpDown1.Value < 60 Then
                ComboBox6.Enabled = True
                ComboBox6.Items.Remove("No Berth Alotted")
                ComboBox6.Items.Remove("No Berth")
                TextBox6.Text = "ADULT (FULL FARE)"
            ElseIf NumericUpDown1.Value >= 60 Then
                ComboBox6.Enabled = True
                ComboBox6.Items.Remove("No Berth Alotted")
                ComboBox6.Items.Remove("No Berth")
                TextBox6.Text = "SENIOR CITIZEN (CONCESSION AVAILABLE)"
            End If
        ElseIf NumericUpDown1.Value > 11 Then
            ComboBox6.Enabled = True
            ComboBox6.Items.Remove("No Berth Alotted")
            ComboBox6.Items.Remove("No Berth")
            TextBox6.Text = "HANDICAP/ESCORT (CONCESSION AVAILABLE)"
        End If
    End Sub
    Private Sub NumericUpDown2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown2.ValueChanged
        If NumericUpDown2.Value < 5 Then
            If Not ComboBox7.Items.Contains("No Berth Alotted") Then
                ComboBox7.Items.Add("No Berth Alotted")
            End If
            ComboBox7.SelectedItem = "No Berth Alotted"
            ComboBox7.Enabled = False
            TextBox7.Text = "CHILD (TICKET NOT NEEDED)"
        ElseIf NumericUpDown2.Value >= 5 And NumericUpDown2.Value <= 11 Then
            ComboBox7.Enabled = True
            If Not ComboBox7.Items.Contains("No Berth") Then
                ComboBox7.Items.Add("No Berth")
            End If
            ComboBox7.Items.Remove("No Berth Alotted")
            ComboBox7.SelectedItem = "No Berth"
            TextBox7.Text = "CHILD (HALF THE ADULT FARE)"
        End If
        If Form2.RadioButton2.Checked = False Then
            If NumericUpDown2.Value > 11 And NumericUpDown2.Value < 60 Then
                ComboBox7.Enabled = True
                ComboBox7.Items.Remove("No Berth Alotted")
                ComboBox7.Items.Remove("No Berth")
                TextBox7.Text = "ADULT (FULL FARE)"
            ElseIf NumericUpDown2.Value >= 60 Then
                ComboBox7.Enabled = True
                ComboBox7.Items.Remove("No Berth Alotted")
                ComboBox7.Items.Remove("No Berth")
                TextBox7.Text = "SENIOR CITIZEN (CONCESSION AVAILABLE)"
            End If
        ElseIf NumericUpDown2.Value > 11 Then
            ComboBox7.Enabled = True
            ComboBox7.Items.Remove("No Berth Alotted")
            ComboBox7.Items.Remove("No Berth")
            TextBox7.Text = "HANDICAP/ESCORT (CONCESSION AVAILABLE)"
        End If
    End Sub
    Private Sub NumericUpDown3_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown3.ValueChanged
        If NumericUpDown3.Value < 5 Then
            If Not ComboBox8.Items.Contains("No Berth Alotted") Then
                ComboBox8.Items.Add("No Berth Alotted")
            End If
            ComboBox8.SelectedItem = "No Berth Alotted"
            ComboBox8.Enabled = False
            TextBox8.Text = "CHILD (TICKET NOT NEEDED)"
        ElseIf NumericUpDown3.Value >= 5 And NumericUpDown3.Value <= 11 Then
            ComboBox8.Enabled = True
            If Not ComboBox8.Items.Contains("No Berth") Then
                ComboBox8.Items.Add("No Berth")
            End If
            ComboBox8.Items.Remove("No Berth Alotted")
            ComboBox8.SelectedItem = "No Berth"
            TextBox8.Text = "CHILD (HALF THE ADULT FARE)"
        End If
        If Form2.RadioButton2.Checked = False Then
            If NumericUpDown3.Value > 11 And NumericUpDown3.Value < 60 Then
                ComboBox8.Enabled = True
                ComboBox8.Items.Remove("No Berth Alotted")
                ComboBox8.Items.Remove("No Berth")
                TextBox8.Text = "ADULT (FULL FARE)"
            ElseIf NumericUpDown3.Value >= 60 Then
                ComboBox8.Enabled = True
                ComboBox8.Items.Remove("No Berth Alotted")
                ComboBox8.Items.Remove("No Berth")
                TextBox8.Text = "SENIOR CITIZEN (CONCESSION AVAILABLE)"
            End If
        ElseIf NumericUpDown3.Value > 11 Then
            ComboBox8.Enabled = True
            ComboBox8.Items.Remove("No Berth Alotted")
            ComboBox8.Items.Remove("No Berth")
            TextBox8.Text = "HANDICAP/ESCORT (CONCESSION AVAILABLE)"
        End If
    End Sub
    Private Sub NumericUpDown4_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown4.ValueChanged
        If NumericUpDown4.Value < 5 Then
            ComboBox9.Enabled = False
            If Not ComboBox9.Items.Contains("No Berth Alotted") Then
                ComboBox9.Items.Add("No Berth Alotted")
            End If
            ComboBox9.SelectedItem = "No Berth Alotted"
            TextBox9.Text = "CHILD (TICKET NOT NEEDED)"
        ElseIf NumericUpDown4.Value >= 5 And NumericUpDown4.Value <= 11 Then
            ComboBox9.Enabled = True
            If Not ComboBox9.Items.Contains("No Berth") Then
                ComboBox9.Items.Add("No Berth")
            End If
            ComboBox9.Items.Remove("No Berth Alotted")
            ComboBox9.SelectedItem = "No Berth"
            TextBox9.Text = "CHILD (HALF THE ADULT FARE)"
        End If
        If Form2.RadioButton2.Checked = False Then
            If NumericUpDown4.Value > 11 And NumericUpDown4.Value < 60 Then
                ComboBox9.Enabled = True
                ComboBox9.Items.Remove("No Berth Alotted")
                ComboBox9.Items.Remove("No Berth")
                TextBox9.Text = "ADULT (FULL FARE)"
            ElseIf NumericUpDown4.Value >= 60 Then
                ComboBox9.Enabled = True
                ComboBox9.Items.Remove("No Berth Alotted")
                ComboBox9.Items.Remove("No Berth")
                TextBox9.Text = "SENIOR CITIZEN (CONCESSION AVAILABLE)"
            End If
        ElseIf NumericUpDown4.Value > 11 Then
            ComboBox9.Enabled = True
            ComboBox9.Items.Remove("No Berth Alotted")
            ComboBox9.Items.Remove("No Berth")
            TextBox9.Text = "HANDICAP/ESCORT (CONCESSION AVAILABLE)"
        End If
    End Sub
    Private Sub NumericUpDown5_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown5.ValueChanged
        If NumericUpDown5.Value < 5 Then
            If Not ComboBox10.Items.Contains("No Berth Alotted") Then
                ComboBox10.Items.Add("No Berth Alotted")
            End If
            ComboBox10.SelectedItem = "No Berth Alotted"
            ComboBox10.Enabled = False
            TextBox10.Text = "CHILD (TICKET NOT NEEDED)"
        ElseIf NumericUpDown5.Value >= 5 And NumericUpDown5.Value <= 11 Then
            ComboBox10.Enabled = True
            If Not ComboBox10.Items.Contains("No Berth") Then
                ComboBox10.Items.Add("No Berth")
            End If
            ComboBox10.Items.Remove("No Berth Alotted")
            ComboBox10.SelectedItem = "No Berth"
            TextBox10.Text = "CHILD (HALF THE ADULT FARE)"
        End If
        If Form2.RadioButton2.Checked = False Then
            If NumericUpDown5.Value > 11 And NumericUpDown5.Value < 60 Then
                ComboBox10.Enabled = True
                ComboBox10.Items.Remove("No Berth Alotted")
                ComboBox10.Items.Remove("No Berth")
                TextBox10.Text = "ADULT (FULL FARE)"
            ElseIf NumericUpDown5.Value >= 60 Then
                ComboBox10.Enabled = True
                ComboBox10.Items.Remove("No Berth Alotted")
                ComboBox10.Items.Remove("No Berth")
                TextBox10.Text = "SENIOR CITIZEN (CONCESSION AVAILABLE)"
            End If
        ElseIf NumericUpDown5.Value > 11 Then
            ComboBox10.Enabled = True
            ComboBox10.Items.Remove("No Berth Alotted")
            ComboBox10.Items.Remove("No Berth")
            TextBox10.Text = "HANDICAP/ESCORT (CONCESSION AVAILABLE)"
        End If
    End Sub
    Private Sub NumericUpDown7_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown7.ValueChanged
        If NumericUpDown7.Value < 5 Then
            If Not ComboBox18.Items.Contains("No Berth Alotted") Then
                ComboBox18.Items.Add("No Berth Alotted")
            End If
            ComboBox18.SelectedItem = "No Berth Alotted"
            ComboBox18.Enabled = False
            TextBox11.Text = "CHILD (TICKET NOT NEEDED)"
        ElseIf NumericUpDown7.Value >= 5 And NumericUpDown7.Value < 11 Then
            ComboBox18.Enabled = True
            If Not ComboBox18.Items.Contains("No Berth") Then
                ComboBox18.Items.Add("No Berth")
            End If
            ComboBox18.Items.Remove("No Berth Alotted")
            ComboBox18.SelectedItem = "No Berth"
            TextBox11.Text = "CHILD (HALF THE ADULT FARE)"
        End If
        If Form2.RadioButton2.Checked = False Then
            If NumericUpDown7.Value > 11 And NumericUpDown7.Value < 60 Then
                ComboBox18.Enabled = True
                ComboBox18.Items.Remove("No Berth Alotted")
                ComboBox18.Items.Remove("No Berth")
                TextBox11.Text = "ADULT (FULL FARE)"
            ElseIf NumericUpDown7.Value >= 60 Then
                ComboBox18.Enabled = True
                ComboBox18.Items.Remove("No Berth Alotted")
                ComboBox18.Items.Remove("No Berth")
                TextBox11.Text = "SENIOR CITIZEN (CONCESSION AVAILABLE)"
            End If
        ElseIf NumericUpDown7.Value > 11 Then
            ComboBox18.Enabled = True
            ComboBox18.Items.Remove("No Berth Alotted")
            ComboBox18.Items.Remove("No Berth")
            TextBox11.Text = "HANDICAP/ESCORT (CONCESSION AVAILABLE)"
        End If
    End Sub

    Private Sub BERTH_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox6.SelectedIndexChanged, ComboBox7.SelectedIndexChanged, ComboBox8.SelectedIndexChanged, ComboBox9.SelectedIndexChanged, ComboBox10.SelectedIndexChanged, ComboBox18.SelectedIndexChanged
        If NumericUpDown1.Value >= 5 And NumericUpDown1.Value <= 11 Then TextBox6.Text = "Full fare will be charged As Berth is opted for child"
        If ComboBox6.SelectedItem = "No Berth" Then TextBox6.Text = "CHILD (HALF THE ADULT FARE)"
        If NumericUpDown2.Value >= 5 And NumericUpDown2.Value <= 11 Then TextBox7.Text = "Full fare will be charged As Berth is opted for child"
        If ComboBox7.SelectedItem = "No Berth" Then TextBox7.Text = "CHILD (HALF THE ADULT FARE)"
        If NumericUpDown3.Value >= 5 And NumericUpDown3.Value <= 11 Then TextBox8.Text = "Full fare will be charged As Berth is opted for child"
        If ComboBox8.SelectedItem = "No Berth" Then TextBox8.Text = "CHILD (HALF THE ADULT FARE)"
        If NumericUpDown4.Value >= 5 And NumericUpDown4.Value <= 11 Then TextBox9.Text = "Full fare will be charged As Berth is opted for child"
        If ComboBox9.SelectedItem = "No Berth" Then TextBox9.Text = "CHILD (HALF THE ADULT FARE)"
        If NumericUpDown5.Value >= 5 And NumericUpDown5.Value <= 11 Then TextBox10.Text = "Full fare will be charged As Berth is opted for child"
        If ComboBox10.SelectedItem = "No Berth" Then TextBox10.Text = "CHILD (HALF THE ADULT FARE)"
        If NumericUpDown7.Value >= 5 And NumericUpDown7.Value <= 11 Then TextBox11.Text = "Full fare will be charged As Berth is opted for child"
        If ComboBox18.SelectedItem = "No Berth" Then TextBox11.Text = "CHILD (HALF THE ADULT FARE)"
    End Sub

    Private Sub NAME_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged, TextBox2.TextChanged, TextBox3.TextChanged, TextBox4.TextChanged, TextBox5.TextChanged, TextBox12.TextChanged
        Dim allowed As String = ("abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        For Each c As Char In TextBox1.Text
            If allowed.Contains(c) = False Then
                MsgBox("Enter Passenger name without Special Characters and Numbers", MsgBoxStyle.Critical, "INVALID ENTRY")
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.SelectionStart - 1, 1)
                TextBox1.Select(TextBox1.Text.Count, 0)
            End If
        Next
        For Each c As Char In TextBox2.Text
            If allowed.Contains(c) = False Then
                MsgBox("Enter Passenger name without Special Characters and Numbers", MsgBoxStyle.Critical, "INVALID ENTRY")
                TextBox2.Text = TextBox2.Text.Remove(TextBox2.SelectionStart - 1, 1)
                TextBox2.Select(TextBox2.Text.Count, 0)
            End If
        Next
        For Each c As Char In TextBox3.Text
            If allowed.Contains(c) = False Then
                MsgBox("Enter Passenger name without Special Characters and Numbers", MsgBoxStyle.Critical, "INVALID ENTRY")
                TextBox3.Text = TextBox3.Text.Remove(TextBox3.SelectionStart - 1, 1)
                TextBox3.Select(TextBox3.Text.Count, 0)
            End If
        Next
        For Each c As Char In TextBox4.Text
            If allowed.Contains(c) = False Then
                MsgBox("Enter Passenger name without Special Characters and Numbers", MsgBoxStyle.Critical, "INVALID ENTRY")
                TextBox4.Text = TextBox4.Text.Remove(TextBox4.SelectionStart - 1, 1)
                TextBox4.Select(TextBox4.Text.Count, 0)
            End If
        Next
        For Each c As Char In TextBox5.Text
            If allowed.Contains(c) = False Then
                MsgBox("Enter Passenger name without Special Characters and Numbers", MsgBoxStyle.Critical, "INVALID ENTRY")
                TextBox5.Text = TextBox5.Text.Remove(TextBox5.SelectionStart - 1, 1)
                TextBox5.Select(TextBox5.Text.Count, 0)
            End If
        Next
        For Each c As Char In TextBox12.Text
            If allowed.Contains(c) = False Then
                MsgBox("Enter Passenger name without Special Characters and Numbers", MsgBoxStyle.Critical, "INVALID ENTRY")
                TextBox12.Text = TextBox12.Text.Remove(TextBox12.SelectionStart - 1, 1)
                TextBox12.Select(TextBox12.Text.Count, 0)
            End If
        Next
        Button1.Show()
    End Sub

    Private Sub NAME_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.Leave, TextBox2.Leave, TextBox3.Leave, TextBox4.Leave, TextBox5.Leave, TextBox12.Leave
        If TextBox1.TextLength > 0 And TextBox1.TextLength < 3 Then
            TextBox1.Clear()
            Button1.Hide()
            MsgBox("Name length should be between 3 and 15", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
        End If
        If TextBox2.TextLength > 0 And TextBox2.TextLength < 3 Then
            TextBox2.Clear()
            Button1.Hide()
            MsgBox("Name length should be between 3 and 15", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
        End If
        If TextBox3.TextLength > 0 And TextBox3.TextLength < 3 Then
            TextBox3.Clear()
            Button1.Hide()
            MsgBox("Name length should be between 3 and 15", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
        End If
        If TextBox4.TextLength > 0 And TextBox4.TextLength < 3 Then
            TextBox4.Clear()
            Button1.Hide()
            MsgBox("Name length should be between 3 and 15", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
        End If
        If TextBox5.TextLength > 0 And TextBox5.TextLength < 3 Then
            TextBox5.Clear()
            Button1.Hide()
            MsgBox("Name length should be between 3 and 15", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
        End If
        If TextBox12.TextLength > 0 And TextBox12.TextLength < 3 Then
            TextBox12.Clear()
            Button1.Hide()
            MsgBox("Name length should be between 3 and 15", MsgBoxStyle.Exclamation, "PASSENGER DETAILS")
        End If
    End Sub

    Private Sub Label21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label21.Click
        MsgBox("TRAIN SCHEDULE CURRENTLY NOT AVAILABLE" + vbNewLine + "SORRY FOR THE INCONVENIENCE", MsgBoxStyle.Information, "TRAIN DETAILS")
    End Sub
    Private Sub Label28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label28.Click
        MsgBox("Berth preference does not guarantee allotment of preferred berth type." + vbNewLine +
"If you need assured Lower Berths or assured compact accommodation (in same coach), please select one of the options." + vbNewLine +
"If 'No Preference' is selected, the berths will be allotted based on the system logic, depending on availability at that point of time." + vbNewLine +
"This choice shall not be applicable in case confirmed accommodation is not available in the train.", MsgBoxStyle.Information, "BERTH PREFERENCE")
    End Sub
End Class