﻿Imports System.Data.SqlClient
Public Class Form4
    Public con As SqlConnection = New SqlConnection("Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = master; Integrated Security = True")
    Private Sub Form4_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        If Not Form2.type = 0 Then
            Me.Text = "TICKET DETAILS"
            Button1.Hide()
            If Form2.type = 1 Then
                Button2.Location = New Point(731, 694)
                Button7.Hide()
            End If
            Button3.Text = "BOOK NEW"
            Button4.Text = "CLOSE"
            If Form2.type = 2 Or Form2.type = 3 Then
                Button5.Hide()
                Button7.Show()
            End If
            Label85.Hide()
            Label86.Hide()
            If Form2.type = 3 Then
                Label84.Text = "CANCELLED"
                Label84.ForeColor = Color.Red
                Label85.Show()
                Label86.Show()
            End If
            Dim da As SqlDataAdapter = New SqlDataAdapter("select * from TRAINS where TRAIN_NUMBER = " + Label57.Text + "", con)
            Dim ds As DataSet = New DataSet()
            da.Fill(ds, "TRAINS")
            Label1.Text = ds.Tables(0).Rows(0).Item(1)
            Label3.Text = ds.Tables(0).Rows(0).Item(2)
            Label59.Text = ds.Tables(0).Rows(0).Item(3)
            Label4.Text = ds.Tables(0).Rows(0).Item(4)
            Label61.Text = ds.Tables(0).Rows(0).Item(5)
            Label72.Text = ds.Tables(0).Rows(0).Item(6) & "/- Rs."
            Dim dd As SqlDataAdapter = New SqlDataAdapter("select * from HISTORY where PNR_NUM = " + Label82.Text + "", con)
            Dim dt As DataSet = New DataSet()
            dd.Fill(dt, "HISTORY")
            Label71.Text = dt.Tables(0).Rows(0).Item(5)
            Label10.Text = dt.Tables(0).Rows(0).Item(6)
            Label63.Text = dt.Tables(0).Rows(0).Item(7)
            Label65.Text = dt.Tables(0).Rows(0).Item(8)
            Label86.Text = dt.Tables(0).Rows(0).Item(9)

            Dim n, a, g, b, t, h, v, u As Integer
            v = Val(Label10.Text) - 1 : n = 18 : a = 30 : g = 36 : b = 42 : t = 48 : h = 24 : u = 88
            For z As Integer = 0 To v
                Dim nam = Controls("Label" & n) : Dim age = Controls("Label" & a):Dim gen = Controls("Label" & g):Dim ber = Controls("Label" & b):Dim nat = Controls("Label" & t):Dim cha = Controls("Label" & h):Dim sea = Controls("Label" & u)
                Dim de As SqlDataAdapter = New SqlDataAdapter("select * from DETAILS where PNR_NO = " + Label82.Text + "", con)
                Dim dset As DataSet = New DataSet() : de.Fill(dset, "DETAILS")
                nam.Text = dset.Tables(0).Rows(z).Item(1)
                age.Text = dset.Tables(0).Rows(z).Item(2)
                gen.Text = dset.Tables(0).Rows(z).Item(3)
                ber.Text = dset.Tables(0).Rows(z).Item(4)
                nat.Text = dset.Tables(0).Rows(z).Item(5)
                cha.Text = dset.Tables(0).Rows(z).Item(6)
                sea.Text = dset.Tables(0).Rows(z).Item(7)
                n += 1 : a += 1 : g += 1 : b += 1 : t += 1 : h += 1 : u += 1 : Next
        ElseIf Form2.type = 0 Then
            For c As Integer = 80 To 93
                Dim lbl = Controls("Label" & c)
                lbl.Hide()
            Next
            Button5.Hide()
            Button6.Hide()
            Button7.Hide()
            Dim j As Integer, i As Integer = 1, k As Integer = 1, l As Integer = 1
            For j = 18 To 29 : If j = 23 Then j += 1
                Dim txt = Controls("Label" & j) : txt.Text = Form3.pn(i) : i += 1 : Next
            For j = 30 To 35 : If k = 6 Then k += 1
                Dim txt = Controls("Label" & j) : txt.Text = Form3.pa(k) : k += 1 : Next
            For j = 36 To 53 : If j = 41 Or j = 47 Then j += 1 : If l = 16 Then l += 1
                Dim txt = Controls("Label" & j) : txt.Text = Form3.pg(l) : l += 1 : Next
            Label1.Text = Form3.Label1.Text : Label2.Text = Form3.Label2.Text
            Label3.Text = Form3.Label3.Text
            Label4.Text = Form3.Label4.Text
            Label10.Text = Form3.NumericUpDown6.Value
            Label23.Text = Form3.TextBox12.Text
            Label41.Text = Form3.ComboBox19.SelectedItem
            Label47.Text = Form3.ComboBox18.SelectedItem
            Label57.Text = Form3.Label21.Text
            Label59.Text = Form3.Label19.Text
            Label61.Text = Form3.Label20.Text
            Label63.Text = Form3.Label34.Text
            Label65.Text = Form2.ComboBox16.SelectedItem
            Label72.Text = Form3.Label23.Text
            Dim co As String = Nothing
            If Label65.Text = "Sleeper Class" Then co = "S"
            If Label65.Text = "I-Class AC" Then co = "A"
            If Label65.Text = "II-Class AC" Then co = "B"
            If Label65.Text = "III-Class AC" Then co = "C"
            Dim seat As Integer = Val(Form2.sa) : For m = 88 To 93
                Dim txt = Controls("Label" & m) : txt.Text = co & seat : seat -= 1 : Next : End If

        Dim d As Integer = Val(Label10.Text), p, s As Integer
        For Each ctl In Controls : If TypeOf ctl Is Label Then
                If ctl.Text = "CHILD (TICKET NOT NEEDED)" Then d -= 1
                If ctl.Text = "CHILD (HALF THE ADULT FARE)" Then p += Val(Label72.Text) / 2
                If ctl.Text = "SENIOR CITIZEN (CONCESSION AVAILABLE)" Or ctl.Text = "HANDICAP/ESCORT (CONCESSION AVAILABLE)" Then s = Val(Label72.Text) * 0.1
            End If : Next

        If Label65.Text = "Sleeper Class" Then Label66.Text = "0"
        If Label65.Text = "I-Class AC" Then Label66.Text = Val(Label72.Text) * 0.9 & "/-Rs."
        If Label65.Text = "II-Class AC" Then Label66.Text = Val(Label72.Text) * 0.7 & "/-Rs."
        If Label65.Text = "III-Class AC" Then Label66.Text = Val(Label72.Text) * 0.5 & "/-Rs."
        Label70.Text = Val(Label72.Text) * 0.09 & "/-Rs."
        Label71.Text = (Val(Label72.Text) + Val(Label66.Text) + Val(Label70.Text) - (p) - (s)) * d & "/- Rs."

        If Val(Label10.Text) = 1 Then
            Label13.Hide()
            Label14.Hide()
            Label67.Hide()
            Label68.Hide()
            Label69.Hide()
            For c As Integer = 19 To 93
                If c = 30 Or c = 36 Or c = 42 Or c = 48 Or c = 24 Then
                    c += 1
                End If
                If c = 54 Then
                    c += 35
                End If
                Dim lbl = Controls("Label" & c)
                lbl.Hide()
            Next
        ElseIf Val(Label10.Text) = 2 Then
            Label14.Hide()
            Label67.Hide()
            Label68.Hide()
            Label69.Hide()
            For c As Integer = 20 To 93
                If c = 30 Or c = 36 Or c = 42 Or c = 48 Or c = 24 Then
                    c += 2
                End If
                If c = 54 Then
                    c += 36
                End If
                Dim lbl = Controls("Label" & c)
                lbl.Hide()
            Next
        ElseIf Val(Label10.Text) = 3 Then
            Label67.Hide()
            Label68.Hide()
            Label69.Hide()
            For c As Integer = 21 To 93
                If c = 30 Or c = 36 Or c = 42 Or c = 48 Or c = 24 Then
                    c += 3
                End If
                If c = 54 Then
                    c += 37
                End If
                Dim lbl = Controls("Label" & c)
                lbl.Hide()
            Next
        ElseIf Val(Label10.Text) = 4 Then
            Label68.Hide()
            Label69.Hide()
            For c As Integer = 22 To 93
                If c = 30 Or c = 36 Or c = 42 Or c = 48 Or c = 24 Then
                    c += 4
                End If
                If c = 54 Then
                    c += 38
                End If
                Dim lbl = Controls("Label" & c)
                lbl.Hide()
            Next
        ElseIf Val(Label10.Text) = 5 Then
            Label69.Hide()
            For c As Integer = 23 To 93
                If c = 30 Or c = 36 Or c = 42 Or c = 48 Or c = 24 Then
                    c += 5
                End If
                If c = 54 Then
                    c += 39
                End If
                Dim lbl = Controls("Label" & c)
                lbl.Hide()
            Next
        End If
        con.Close()
    End Sub
    Private Sub PAY(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        con.Open()
        Dim com As SqlCommand = New SqlCommand("INSERT INTO HISTORY VALUES ('" + Label57.Text + "','" + Label2.Text + "','" + DateAndTime.Now + "','CONFIRMED','" + Label71.Text + "','" + Label10.Text + "','" + Label63.Text + "','" + Label65.Text + "','" + Label86.Text + "')", con)
        Dim dr = com.ExecuteReader() : dr.Read() : dr.Close()
        Dim n, a, g, b, t, h, s As Integer
        n = 18 : a = 30 : g = 36 : b = 42 : t = 48 : h = 24 : s = 88
        For i As Integer = 1 To Val(Label10.Text)
            Dim nam = Controls("Label" & n)
            Dim age = Controls("Label" & a)
            Dim gen = Controls("Label" & g)
            Dim ber = Controls("Label" & b)
            Dim nat = Controls("Label" & t)
            Dim cha = Controls("Label" & h)
            Dim sea = Controls("Label" & s)
            Dim cmd As SqlCommand = New SqlCommand("INSERT INTO DETAILS VALUES ((SELECT TOP 1 PNR_NUM FROM HISTORY ORDER BY PNR_NUM DESC),'" + nam.Text + "','" + age.Text + "','" + gen.Text + "','" + ber.Text + "','" + nat.Text + "','" + cha.Text + "','" + sea.Text + "')", con)
            Dim rd = cmd.ExecuteReader() : rd.Read() : rd.Close()
            n += 1 : a += 1 : g += 1 : b += 1 : t += 1 : h += 1 : s += 1 : Next
        MsgBox("TICKET BOOKED SUCESSFULLY!", MsgBoxStyle.Information, "CONFIRMATION")
        If MsgBoxResult.Ok Then
            Button1.Hide()
            Button2.Hide()
            Button3.Text = "BOOK NEW"
            Button4.Text = "CLOSE"
            Button6.Show()
            Label80.Show()
            Label81.Show()
            Label82.Show()
            Label83.Show()
            Label84.Show()
            Label87.Show()
            Label88.Show()
            If Val(Label10.Text) = 2 Then
                Label89.Show()
            ElseIf Val(Label10.Text) = 3 Then
                Label89.Show()
                Label90.Show()
            ElseIf Val(Label10.Text) = 4 Then
                Label89.Show()
                Label90.Show()
                Label91.Show()
            ElseIf Val(Label10.Text) = 5 Then
                Label89.Show()
                Label90.Show()
                Label91.Show()
                Label92.Show()
            ElseIf Val(Label10.Text) = 6 Then
                Label89.Show()
                Label90.Show()
                Label91.Show()
                Label92.Show()
                Label93.Show()
            End If
            Dim cmm As SqlCommand = New SqlCommand("SELECT TOP 1 * FROM HISTORY ORDER BY PNR_NUM DESC", con)
            Dim r = cmm.ExecuteReader() : r.Read()
            Label82.Text = r(0).ToString : Label80.Text = r(3).ToString
            r.Close() : End If : con.Close()
    End Sub
    Private Sub CANCEL(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim i As Integer = MsgBox("ARE YOU SURE...?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.ApplicationModal, "CANCEL TICKET")
        If i = MsgBoxResult.Yes Then:Dim r As String
            r = Val(Label71.Text) - (60 * Val(Label10.Text)) & "/-Rs."
            con.Open()
            Dim cnc As SqlCommand = New SqlCommand("UPDATE HISTORY SET TICKET_STATUS='CANCELLED', REFUNDED_AMOUNT='" + r + "' WHERE PNR_NUM=" + Label82.Text + "", con)
            cnc.ExecuteNonQuery()
            MsgBox("TICKET CANCELLED SUCESSFULLY.", MsgBoxStyle.Information, "CONFIRMATION")
            If MsgBoxResult.Ok Then
                Button2.Hide()
                Button5.Hide()
                Label84.ForeColor = Color.Red
                Label84.Text = "CANCELLED"
                Label84.Show()
                Label85.Show()
                Label86.Show()
                Form2.Close()
                Dim cmm As SqlCommand = New SqlCommand("SELECT TOP 1 * FROM HISTORY ORDER BY PNR_NUM DESC", con)
                Dim c = cmm.ExecuteReader()
                c.Read()
                Label82.Text = c(0).ToString
                Label80.Text = c(3).ToString
                Label86.Text = c(9).ToString
                c.Close()
            End If
        End If
        con.Close()
    End Sub
    Private Sub PRINT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        PrintForm1.PrintFileName = "D:\TRAIN TICKET " & Label2.Text & ".pdf"
        PrintForm1.Print(Me, PowerPacks.Printing.PrintForm.PrintOption.ClientAreaOnly)
        MsgBox("PRINTED TICKET SUCCESSFULLY", MsgBoxStyle.Information, "CONFIRMATION")
    End Sub
    Private Sub RETURN_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
        If Form2.type = 0 Then
            Me.Close()
            Form3.Show()
        Else
            Me.Close()
            Form2.Show()
        End If
    End Sub
    Private Sub NEW_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button3.Click
        If Button3.Text = "REPLAN" Then
            Me.Close()
            Form2.Close()
            Form1.Show()
        Else
            Me.Close()
            Form2.Close()
            Form3.Close()
            Form1.type = 0
            Form1.Show()
        End If
    End Sub
    Private Sub CANCEL_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button4.Click
        If Button4.Text = "CANCEL" Then
            Dim i As Integer = MsgBox("ARE YOU SURE...?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.ApplicationModal, "CLOSE")
            If i = MsgBoxResult.Yes Then
                Me.Close()
                Form2.Close()
                Form3.Close()
                Form1.type = 0
                Form1.Show()
            End If
        Else
            Form1.Close()
        End If
    End Sub
    Private Sub Label57_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label57.Click
        MsgBox("TRAIN SCHEDULE CURRENTLY NOT AVAILABLE" + vbNewLine + "SORRY FOR THE INCONVENIENCE", MsgBoxStyle.Information, "TRAIN DETAILS")
    End Sub
    Private Sub Label82_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label82.Click
        MsgBox("The ID card will be required during journey." + vbNewLine + "One of the passenger booked on ticket should have any of their Valid Photo Identity Card during train journey in original.", MsgBoxStyle.Information, "ID REQUIRED")
    End Sub
    Private Sub DELETE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If Label2.Text < Today OrElse Label84.Text = "CANCELLED" Then
            Dim i As Integer = MsgBox("ARE YOU SURE...?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2 + MsgBoxStyle.ApplicationModal, "DELETE RECORD")
            If i = MsgBoxResult.Yes Then : con.Open()
                Dim com As SqlCommand = New SqlCommand("DELETE FROM HISTORY WHERE PNR_NUM=" + Label82.Text + "", con) : com.ExecuteNonQuery()
                Dim cmd As SqlCommand = New SqlCommand("DELETE FROM DETAILS WHERE PNR_NO NOT IN (SELECT PNR_NUM FROM HISTORY)", con) : cmd.ExecuteNonQuery()
                con.Close() : Form2.Close() : Form1.type = 0 : Form1.Show() : Me.Close() : End If
        Else : MsgBox("ONLY EXPIRED/CANCELLED TICKETS CAN BE DELETED!", MsgBoxStyle.Exclamation, "NOT ALLOWED") : End If
    End Sub : End Class